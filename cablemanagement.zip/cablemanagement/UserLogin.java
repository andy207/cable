
package cablemanagement;


import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;


public class UserLogin extends JFrame{
    static UserLogin frame;
    private JPanel contentPane;
    private JTextField txf;
    private JPasswordField psf;

   public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable(){
            public void run(){
                try{
                    frame = new UserLogin();
                    frame.setVisible(true);
                    
                }
                catch(Exception e)
                {
                    e.printStackTrace();
            }
                
        }
    });
    }
    
    public UserLogin(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100,100,450,300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5,5,5,5));
        setContentPane(contentPane);
        
        JLabel lbl= new JLabel("Users Login Form");
        lbl.setForeground(Color.GRAY);
        lbl.setFont(new Font("Tahoma",Font.PLAIN, 18));
        
        JLabel lbl2= new JLabel("Enter UserName:");
        
        JLabel lbl3= new JLabel("Enetr Password:");
        
        txf= new JTextField();
        txf.setColumns(10);
        
        JButton btnL = new JButton("Login");
        btnL.setForeground(Color.BLUE);
        btnL.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                String name =txf.getText();
                String Password = String.valueOf(psf.getPassword());
                if(name.equals("anand") && Password.equals("anand@123")){
                    UsersSuccess.main(new String[]{});
                    frame.dispose();
                }
                else{
                    JOptionPane.showMessageDialog(UserLogin.this,"Sorry,Username or Password Error,","Login Error!",
                            JOptionPane.ERROR_MESSAGE);
                    txf.setText("");
                    psf.setText("");
                }
            }
        });
        
        psf =new JPasswordField();
        GroupLayout gl_contentPane=new GroupLayout(contentPane);
        gl_contentPane.setHorizontalGroup(
        gl_contentPane.createParallelGroup(Alignment.TRAILING)
                .addGroup(gl_contentPane.createSequentialGroup()
                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                .addGroup(gl_contentPane.createSequentialGroup()
                .addGap(124)
                .addComponent(lbl))
                .addGroup(gl_contentPane.createSequentialGroup()
                .addGap(19)
                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                .addComponent(lbl2)
                .addComponent(lbl3))
                .addGap(47)
                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING,false)
                .addComponent(psf)
                .addComponent(txf,GroupLayout.DEFAULT_SIZE,172,Short.MAX_VALUE))))
                .addContainerGap(107,Short.MAX_VALUE))
                .addGroup(gl_contentPane.createSequentialGroup()
                .addContainerGap(187,Short.MAX_VALUE)
                .addComponent(btnL, GroupLayout.PREFERRED_SIZE,86,GroupLayout.PREFERRED_SIZE)
                .addGap(151))
        );
        gl_contentPane.setVerticalGroup(
        gl_contentPane.createParallelGroup(Alignment.LEADING)
        .addGroup(gl_contentPane.createSequentialGroup()
        .addComponent(lbl)
        .addGap(26)
        .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
        .addComponent(lbl2)
        .addComponent(txf,GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,GroupLayout.PREFERRED_SIZE))
        .addGap(28) 
        .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
        .addComponent(lbl3)
        .addComponent(psf,GroupLayout.PREFERRED_SIZE,GroupLayout.DEFAULT_SIZE,GroupLayout.PREFERRED_SIZE))
        .addGap(18)
        .addComponent(btnL,GroupLayout.PREFERRED_SIZE,37,GroupLayout.PREFERRED_SIZE)
        .addContainerGap(80,Short.MAX_VALUE))
        );
        contentPane.setLayout(gl_contentPane);
}
}

   