
package cablemanagement;

import java.awt.Color;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JFrame;
import java.awt.Font;
import javax.swing.JOptionPane;
public class EmployeeForm{
    
    public static void Connectmethod(String Id,int Age, String FullName, String Qualification, String Experience, String CurrentPosition,
            String Address,String Date, String MobileNo, String Email)
    {
        try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/CableManagement","root","root123");
        PreparedStatement pst= con.prepareStatement("insert into Cliform values(?,?,?,?,?,?,?,?,?,?)");
        
        pst.setString(1, Id);
        pst.setInt(2, Age);
        pst.setString(3, FullName);
        pst.setString(4, Qualification);
        pst.setString(5, Experience);
        pst.setString(6, CurrentPosition);
        pst.setString(7, Address);
        pst.setString(8, Date);
        pst.setString(9, MobileNo);
        pst.setString(10, Email);
        
        
        pst.executeUpdate();
    
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
        public static void main(String[] args)
       {
           //Image img = ImageIO.read(new File("C:\\Users\\Hp\\Pictures\\Wallpapers\\4K-cars-wallpapers-7.jpg"));
            JFrame f =new JFrame("Employee Form");

            final JTextField eidt, eat, ent, eqt, eet, ect, eadt, edt, emt, eemt;
            JLabel eidl, eal, enl,eql, eel, ecl, eadl, edl, eml,eeml;

            eidt = new JTextField();
            eat = new JTextField();
            ent = new JTextField();
            eqt = new JTextField();
            eet= new JTextField();
            ect= new JTextField();
            eadt = new JTextField();
            edt= new JTextField();
            emt = new JTextField();
            eemt = new JTextField();
            
            eidl = new JLabel("Id               :");
            eal = new JLabel("Age               :");
            enl = new JLabel("FullName          :");
            eql = new JLabel("Qualification     :");
            eel = new JLabel("Experience        :");
            ecl = new JLabel("CurrentPosition   :");
            eadl= new JLabel("Address           :");
            edl = new JLabel("Date              :");
            eml = new JLabel("MobileNo.         :");
            eeml = new JLabel("Email            :");

            JButton s = new JButton("Submit");
            JButton r = new JButton("Back");

            s.setBackground(Color.green);
            r.setBackground(Color.red);
            
            eidt.setBounds(150,10,100,20);
            eat.setBounds(150, 50, 100, 20);
            ent.setBounds(150, 90, 100, 20);
            eqt.setBounds(150, 130, 100, 20);
            eet.setBounds(150,170,100,20);
            ect.setBounds(150, 210, 100, 20);
            eadt.setBounds(150,250,100,20);
            edt.setBounds(150,290,100,20);
            emt.setBounds(150,330,100,20);
            eemt.setBounds(150,370,100,20);
            
 
            eidl.setBounds(10,10,140,20);
            eal.setBounds(10, 50, 140, 20);
            enl.setBounds(10, 90, 140, 20);
            eql.setBounds(10, 130, 140, 20);
            eel.setBounds(10,170,140,20);
            ecl.setBounds(10,210,140,20);
            eadl.setBounds(10,250,140,20);
            edl.setBounds(10,290,140,20);
            eml.setBounds(10,330,140,20);
            eeml.setBounds(10,370,140,20);

            s.setBounds(10, 420, 90, 30);
            r.setBounds(150, 420, 90, 30);


            f.add(eidt);
            f.add(eat);
            f.add(ent);
            f.add(eqt);
            f.add(eet);
            f.add(ect);
            f.add(eadt);
            f.add(edt);
            f.add(emt);
            f.add(eemt);
            
            f.add(eidl);
            f.add(eal);
            f.add(enl);
            f.add(eql);
            f.add(eel);
            f.add(ecl);
            f.add(eadl);
            f.add(edl);
            f.add(eml);
            f.add(eeml);
            
            f.add(s);
            f.add(r);

            f.setLayout(null);
            f.setSize(500, 500);
            f.setVisible(true);
            f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            
            s.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            String a= eidt.getText();
            int b = Integer.parseInt(eat.getText());
            String c=ent.getText();
            String d= eqt.getText();
            String g= eet.getText();
            String h= ect.getText();
            String i= eadt.getText();
            String j= edt.getText();
            String k= emt.getText();
            String m= eemt.getText();
            Connectmethod(a,b,c,d,g,h,i,j,k, m);
            JOptionPane.showMessageDialog(f,"Data Added Successfully","Alert",JOptionPane.WARNING_MESSAGE);
            }
            });
            r.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    AdminSuccess.main(new String[]{});
                    f.dispose();
                }
            });
       }
   
}