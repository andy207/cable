
package cablemanagement;

import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


class MK {
    public static void Connectmethod(String CardNo,String STBNo,String FirstName , String LastName,String MobileNo,
           String TelNo,String Date,int RoomNo,String SocietyName, String Email)
          {
        try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/CableManagement","root","root123");
        PreparedStatement pst= con.prepareStatement("insert into MK values(?,?,?,?,?,?,?,?,?,?)");
        
        pst.setString(1, CardNo);
        pst.setString(2, STBNo);
        pst.setString(3, FirstName);
        pst.setString(4, LastName);
        pst.setString(5, MobileNo);
        pst.setString(6, TelNo);
        pst.setString(7, Date);
        pst.setInt(8, RoomNo);
        pst.setString(9, SocietyName);
        pst.setString(10, Email);
        
        pst.executeUpdate();
        
        }
        catch(Exception e){
            System.out.println(e);
        }
    }

   public static void main(String[] args){
       JFrame f = new JFrame("New Users Form");
       
       final JTextField dit,dat, dnt, ddt,dgt,dmt,drt,det,dct,dadt;
       JLabel dil,dal, dnl, ddl, dgl, dml, drl,del,dcl, dadl;
        
       
            dit = new JTextField();
            dat = new JTextField();
            dnt = new JTextField();
            ddt = new JTextField();
            dgt = new JTextField();
            dmt = new JTextField();
            drt = new JTextField();
            det = new JTextField();
            dct = new JTextField();
            dadt = new JTextField();
            
            JLabel dl= new JLabel("Narayan Nagar Section...");
            dl.setFont(new Font("Tahmoa",Font.PLAIN,13));
            dl.setForeground(Color.RED);
            
            dil =new JLabel("CardNo. :");
            dal = new JLabel("STBNO. :");
            dnl = new JLabel("FirstName :");
            ddl = new JLabel("LastName :");
            dgl = new JLabel("MobileNo. :");
            dml = new JLabel("TelNo. :");
            drl = new JLabel("Date :");
            del = new JLabel("RoomNo. :");
            dcl = new JLabel("SocietyName :");
            dadl = new JLabel("Email :");
      
            
            dl.setBounds(10,10,200,20);
            dil.setBounds(10,50,100,20);
            dal.setBounds(10,90,100,20);
            dnl.setBounds(10,130,100,20);
            ddl.setBounds(10,170,100,20);
            dgl.setBounds(10,210,100,20);
            dml.setBounds(10,250,100,20);
            drl.setBounds(10,290,100,20);
            del.setBounds(10,330,100,20);
            dcl.setBounds(10,370,100,20);
            dadl.setBounds(10,410,100,20);
            
            dit.setBounds(110,50,200,20);
            dat.setBounds(110,90,200,20);
            dnt.setBounds(110,130,200,20);
            ddt.setBounds(110,170,200,20);
            dgt.setBounds(110,210,200,20);
            dmt.setBounds(110,250,200,20);
            drt.setBounds(110,290,200,20);
            det.setBounds(110,330,200,20);
            dct.setBounds(110,370,200,20);
            dadt.setBounds(110,410,200,20);
       
            JButton btna = new JButton("Add");
            JButton btnv = new JButton("ViewMK");
            JButton back = new JButton("Back");
            JButton btnc = new JButton("Clear");
            
            btnv.addActionListener(new ActionListener(){
           @Override
           public void actionPerformed(ActionEvent e) {
              ViewMK.main(new String[]{});
           }
                
            });
            
            
            btna.setBounds(10,460,100,30);
            btnv.setBounds(180,460,100,30);
            back.setBounds(290,460,100,30);
            btnc.setBounds(400,460,100,300);
            
            f.add(dl);
            f.add(dil);
            f.add(dal);
            f.add(dnl);
            f.add(ddl);
            f.add(dgl);
            f.add(dml);
            f.add(drl);
            f.add(del);
            f.add(dcl);
            f.add(dadl);
            
            f.add(dit);
            f.add(dat);
            f.add(dnt);
            f.add(ddt);
            f.add(dgt);
            f.add(dmt);
            f.add(drt);
            f.add(det);
            f.add(dct);
            f.add(dadt);
            
            f.add(btna);
            f.add(back);
            f.add(btnv);
            f.add(btnc);
            
            f.setVisible(true);
            f.setSize(550,650);
            f.setLayout(null);
           // f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            btna.addActionListener(new ActionListener(){
           @Override
           public void actionPerformed(ActionEvent e) {
               String a= dit.getText();
               String b = dat.getText();
               String c = dnt.getText();
               String d = ddt.getText();
               String g = dgt.getText();
               String h = dmt.getText();
               String i = drt.getText();
               int j = Integer.parseInt(det.getText());
               String k = dct.getText();
               String l = dadt.getText();
               Connectmethod(a,b,c,d,g,h,i,j,k,l);
               JOptionPane.showMessageDialog(f,"Data Added Successfully","Alert",JOptionPane.WARNING_MESSAGE);
           }
                
            });
            back.addActionListener(new ActionListener(){
           @Override
           public void actionPerformed(ActionEvent e) {
               UsersSuccess.main(new String[]{});
                    f.dispose();
           }
                
            });
           
    }
    
}

