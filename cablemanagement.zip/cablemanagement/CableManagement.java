
package cablemanagement;

import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.LayoutStyle.ComponentPlacement;

public class CableManagement {

     public static void main(String args[]){
        JFrame f = new JFrame("Cabel Management System");
        
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //JLabel image= new JLabel(ImageIcon(""));
        
        JLabel lb = new JLabel("Cabel-Management");
        lb.setForeground(Color.GRAY);
        
        JButton btna = new JButton("Admin Login");
        
         btna.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
               AdminLogin.main(new String[]{}); 
               f.dispose();
            }
            
        });
        
        JButton btnd = new JButton("User Login");
       
        btnd.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                UserLogin.main(new String[]{});
                f.dispose();
            }
            
        });
        
        lb.setBounds(10,10,400,22);
        btna.setBounds(100,70,200,50);
        btnd.setBounds(100,150,200,50);
        
        
        
        f.add(lb);
        f.add(btna);
        f.add(btnd);
        
        
        
        f.setLayout(null);
        f.setVisible(true);
        f.setSize(450,300);
        
    }
    
}
