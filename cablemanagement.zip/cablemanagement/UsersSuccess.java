package cablemanagement;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

public class UsersSuccess{
   public static void main(String args[]){
       JFrame f = new JFrame("UsersSuccess");
       f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       f.setBounds(50,50,500,500);
       
       JLabel lbl = new JLabel("Users Section - Hostel");
       lbl.setFont(new Font("Tahoma",Font.PLAIN,22));
       lbl.setForeground(Color.GRAY);
       
       JButton btna = new JButton ("GS Users");
       btna.setBackground(Color.green);
       btna.addActionListener(new ActionListener(){
           @Override
           public void actionPerformed(ActionEvent e) {
               Gs.main(new String[]{});
              
           }
           
       });
       btna.setFont(new Font("Tahoma",Font.PLAIN,13));
       
       JButton btnar = new JButton ("MK Users");
       btnar.setBackground(Color.green);
       btnar.addActionListener(new ActionListener(){
           @Override
           public void actionPerformed(ActionEvent e) {
               MK.main(new String[]{});
            
           }
       });
       btnar.setFont(new Font("Tahoma",Font.PLAIN,13));
       
       
       JButton btnpf = new JButton ("RJ Users");
       btnpf.setBackground(Color.green);
       btnpf.addActionListener(new ActionListener(){
           @Override
           public void actionPerformed(ActionEvent e) {
               RJ.main(new String[]{});
               f.dispose();
               
           }
           
       });
       btnpf.setFont(new Font("Tahoma",Font.PLAIN,13));
       
       
       JButton btnl = new JButton("Logout");
       btnl.setBackground(Color.red);
       btnl.addActionListener(new ActionListener(){
           @Override
           public void actionPerformed(ActionEvent e) {
               CableManagement.main(new String[]{});
             
           }
           
       });
       btnl.setFont(new Font("Tahoma",Font.PLAIN,13));
       
       lbl.setBounds(10,10,400,40);
       btna.setBounds(150,60,150,40);
     //  btnv.setBounds(150,110,150,40);
       btnar.setBounds(150,160,150,40);
   //    btnvr.setBounds(150,210,150,40);
       btnpf.setBounds(150,260,150,40);
    //   btnvp.setBounds(150,310,150,40);
       btnl.setBounds(150,360,150,40);
       
       f.add(lbl);
       f.add(btna);
    //   f.add(btnv);
       f.add(btnar);
     //  f.add(btnvr);
       f.add(btnpf);
    //  f.add(btnvp);
       f.add(btnl);
       
       f.setLayout(null);
       f.setVisible(true);
   }
}
